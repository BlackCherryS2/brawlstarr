
# Pyla Mobile Lab v0.2 — Live Pipeline

This revision adds the real Android MediaProjection capture path with explicit user consent and a
foreground service. It demonstrates that live frames from another visible app can enter the AI
pipeline. The supplied Pyla ONNX assets remain packaged for detector integration.

Pipeline:
MediaProjection -> RGBA frames -> Detector adapter -> WorldState -> PolicyEngine -> AiAction -> telemetry/Arena.

The Action model includes movement, aim, attack, super, gadget and hypercharge. The autonomous Arena
executes and visualizes decisions. For third-party online games, AiAction is not converted into injected
touch/accessibility events.

Build: Android Studio/JDK17 or the included GitHub Actions workflow.
