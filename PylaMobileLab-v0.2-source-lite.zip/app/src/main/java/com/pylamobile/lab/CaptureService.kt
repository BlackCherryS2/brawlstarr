
package com.pylamobile.lab
import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjectionManager
import android.os.IBinder

class CaptureService: Service() {
    companion object { var latest: FrameStats = FrameStats() }
    private var reader: ImageReader?=null
    override fun onBind(i:Intent?):IBinder?=null
    override fun onStartCommand(i:Intent?, flags:Int, id:Int):Int {
        val ch="capture"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(ch,"Live analysis",NotificationManager.IMPORTANCE_LOW))
        startForeground(7, Notification.Builder(this,ch).setContentTitle("Pyla Mobile Lab")
            .setContentText("Screen analysis active").setSmallIcon(android.R.drawable.ic_menu_view).build())
        val code=i?.getIntExtra("code",-1)?:-1
        val data=i?.getParcelableExtra<Intent>("data")?:return START_NOT_STICKY
        val dm=resources.displayMetrics; val w=dm.widthPixels; val h=dm.heightPixels
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection=pm.getMediaProjection(code,data)
        projection.createVirtualDisplay("PylaCapture",w,h,dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
        reader!!.setOnImageAvailableListener({ r ->
            r.acquireLatestImage()?.use { img ->
                // v0.2 establishes the real live frame path. The ONNX adapter consumes frames next.
                latest=latest.copy(frames=latest.frames+1,width=img.width,height=img.height,
                    timestamp=System.currentTimeMillis())
            }
        },null)
        return START_STICKY
    }
}
data class FrameStats(val frames:Long=0,val width:Int=0,val height:Int=0,val timestamp:Long=0)
