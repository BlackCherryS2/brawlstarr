
package com.pylamobile.lab
import kotlin.math.*
data class Entity(val x:Float,val y:Float,val confidence:Float=1f)
data class WorldState(val player:Entity, val enemies:List<Entity>)
class PolicyEngine {
    fun decide(s:WorldState):AiAction {
        val e=s.enemies.minByOrNull { hypot((it.x-s.player.x).toDouble(),(it.y-s.player.y).toDouble()) }
            ?: return AiAction(0f,0f,0f,false,false,false,false)
        val dx=e.x-s.player.x; val dy=e.y-s.player.y
        val aim=Math.toDegrees(atan2(dy.toDouble(),dx.toDouble())).toFloat()
        val d=hypot(dx.toDouble(),dy.toDouble()).toFloat()
        // Lab policy: computes the same categories of actions, but does not inject touches into another app.
        return AiAction((aim+180f)%360f, if(d<0.18f) .75f else .35f, aim, d<.55f, false, false, false)
    }
}
