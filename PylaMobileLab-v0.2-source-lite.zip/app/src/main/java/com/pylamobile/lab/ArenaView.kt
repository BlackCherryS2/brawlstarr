
package com.pylamobile.lab
import android.content.Context
import android.graphics.*
import android.view.*
import kotlin.math.*
class ArenaView(c:Context):View(c) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private var player=Entity(.5f,.78f); private var enemy=Entity(.5f,.2f)
    private var action=AiAction(0f,0f,0f,false,false,false,false)
    fun setAction(a:AiAction){action=a; invalidate()}
    override fun onDraw(ca:Canvas){
        super.onDraw(ca); ca.drawColor(Color.rgb(9,13,22))
        fun dot(e:Entity,label:String){
            p.style=Paint.Style.FILL;p.color=if(label=="AI") Color.CYAN else Color.MAGENTA
            ca.drawCircle(e.x*width,e.y*height,28f,p);p.textSize=26f;ca.drawText(label,e.x*width+38,e.y*height,p)
        }
        dot(player,"AI");dot(enemy,"ENEMY")
        p.color=Color.WHITE;p.textSize=28f
        ca.drawText("MOVE %.0f°  AIM %.0f°  ATTACK %s".format(action.moveAngle,action.aimAngle,action.attack),32f,48f,p)
        val r=Math.toRadians(action.aimAngle.toDouble()); p.strokeWidth=6f
        ca.drawLine(player.x*width,player.y*height,
            player.x*width+cos(r).toFloat()*220,player.y*height+sin(r).toFloat()*220,p)
    }
    fun state()=WorldState(player,listOf(enemy))
}
