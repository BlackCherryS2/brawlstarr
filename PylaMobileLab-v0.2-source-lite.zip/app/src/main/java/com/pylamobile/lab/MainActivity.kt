
package com.pylamobile.lab
import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
    private val REQ=44
    private lateinit var status:TextView
    override fun onCreate(b:Bundle?){super.onCreate(b)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,18,24,18)}
        root.addView(TextView(this).apply{text="PYLA MOBILE LAB • LIVE v0.2";textSize=22f})
        val live=Button(this).apply{text="START LIVE SCREEN ANALYSIS"}
        status=TextView(this).apply{text="Waiting for capture permission…";textSize=18f;setPadding(0,20,0,20)}
        val arena=ArenaView(this)
        root.addView(live);root.addView(status)
        root.addView(arena,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        live.setOnClickListener{
            val pm=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(pm.createScreenCaptureIntent(),REQ)
        }
        val h=Handler(Looper.getMainLooper())
        fun tick(){
            val s=CaptureService.latest
            status.text="LIVE FRAME PATH  ${s.width}×${s.height}   frames=${s.frames}\nCapture → detector → WorldState → Policy → Action"
            h.postDelayed({tick()},500)
        };tick()
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==REQ && res==Activity.RESULT_OK && data!=null){
            val i=Intent(this,CaptureService::class.java).putExtra("code",res).putExtra("data",data)
            startForegroundService(i)
        }
    }
}
