
package com.pylamobile.lab
data class AiAction(
    val moveAngle: Float, val moveStrength: Float, val aimAngle: Float,
    val attack: Boolean, val useSuper: Boolean, val gadget: Boolean, val hypercharge: Boolean
)
interface ActionSink { fun submit(action: AiAction) }
class OverlayActionSink(private val onAction:(AiAction)->Unit): ActionSink {
    override fun submit(action: AiAction) = onAction(action)
}
