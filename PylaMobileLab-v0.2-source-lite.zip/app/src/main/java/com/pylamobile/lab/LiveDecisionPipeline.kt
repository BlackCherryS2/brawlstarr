
package com.pylamobile.lab
/**
 * Live pipeline boundary:
 * captured frame -> detector -> WorldState -> PolicyEngine -> AiAction.
 * AiAction is exposed as telemetry/overlay; it is intentionally not injected into another app.
 */
class LiveDecisionPipeline {
    private val policy=PolicyEngine()
    fun decide(state:WorldState):AiAction = policy.decide(state)
}
