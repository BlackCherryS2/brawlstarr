Large ONNX model files are intentionally excluded from this GitHub-uploadable package
to keep the ZIP below GitHub's web upload limit.

Expected model names:
- mainInGameModel.onnx
- tileDetector.onnx
- closeTileDetector.onnx

The Android project can build without bundling these research model assets.
Add compatible model assets later under app/src/main/assets/models/.
